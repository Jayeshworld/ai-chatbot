<?php

use App\Http\Controllers\Web\ChatbotController;
use Illuminate\Support\Facades\Route;

Route::get('/', [ChatbotController::class, 'index']);
Route::get('/chat', [ChatbotController::class, 'index']);
